Display
-------
Either call it directly
http://YOUR_SERVER:8080/weather?locationId=...&layout=example&iconset=colorful

or with a sitemap:
Webview url="/weather?locationId=...&layout=example&iconset=colorful" height=7
